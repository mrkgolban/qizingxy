#include "./lib/qizingxy.h"
#include <iostream>
#include <xtensor/containers/xarray.hpp>
#include <xtensor/io/xio.hpp>
int main() {
  xt::xarray<double> A = {{1, 2}, {3, 4}};
  xt::xarray<double> B = {{5, 6}, {7, 8}};
  Spin a(1, 2, 3);
  std::cout << "Spin's been succesfully created" << std::endl;
  Hamilitonian H(10, 3, 1.0, 2.0, 0.5, 2, 3);
}
