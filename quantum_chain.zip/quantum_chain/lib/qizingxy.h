#pragma once
#include <xtensor/containers/xarray.hpp>
#include <xtensor/containers/xtensor.hpp>
#include <xtensor/io/xio.hpp>
class Spin {
private:
  int x, y;
  int spin;
  static int amount;

public:
  Spin(int xx, int yy, int sspin);
};

class Hamilitonian {
private:
  // H = -J * ((1 + gamma) * sigma^x_i+1 * sigma^x_i + (1-gamma) * sigma^y_i+1 *
  // sigma^y_i) - h sigma^z_i
  long unsigned int N;
  int dim;
  int height;
  int length;
  int h;
  int J;
  int gamma; // -1 <= gamma <= 1
  xt::xarray<double> ham;

public:
  Hamilitonian(int NN, int ddim, int hh, int JJ, int ggama, int hheight,
               int llength);
  void change_grid(int new_length, int new_height);
  void change_amount(int newN);
};
