#include "./qizingxy.h"

Spin::Spin(int xx, int yy, int sspin) : x(xx), y(yy), spin(sspin) {};
Hamilitonian::Hamilitonian(int NN, int ddim, int hh, int JJ, int ggamma,
                           int hheight, int llength)
    : N((long unsigned int)NN), dim(ddim), h(hh), J(JJ), gamma(ggamma),
      length(llength), height(hheight) {
  ham = xt::zeros<double>(
      {static_cast<std::size_t>(N), static_cast<std::size_t>(N)});

  change_grid(length, height);
};

void Hamilitonian::change_grid(int llength, int hheight) {
  ham.reshape({2, 3});
};
